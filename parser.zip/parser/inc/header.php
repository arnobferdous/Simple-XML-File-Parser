<!DOCTYPE html>
<head>
  <title>XML File parser using javascript</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
  <script type="text/javascript" src="assets/js/jquery-script.js"></script>
</head>
<body>
<div class="container">
