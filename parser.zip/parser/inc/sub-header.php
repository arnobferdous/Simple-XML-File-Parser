<div class="row">
  <div class="col-md-6">
    <h2>XML File Parser</h2>
    <p><b>Team Members</b></p>
    <ul>
      <li>Babe Sultana Ummeya</li>
      <li>Farzana Rahman Mumu (ID# 142002001)</li>
      <li>Kamrunnahar Nisha</li>
    </ul>
  </div>
  <div class="col-md-6">
  <h2>Project Goal:</h2>
  <p>The goal is to develop this project is reading, writing, deleting, updating data and writing to a XML file. On the other hand
  this project will read data from the uploaded XML file. File and data validation is also added here.</p>
  </div>
</div>
