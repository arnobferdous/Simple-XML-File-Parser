<?php require_once('inc/header.php'); ?>
  <div class="row">
    <div class="col-md-6">
      <h2>XML File Parser</h2>
      <p><b>Team Members</b></p>
      <ul>
        <li>Babe Sultana Ummeya</li>
        <li>Farzana Rahman Mumu (ID# 142002001)</li>
        <li>Kamrunnahar Nisha</li>
      </ul>
    </div>
    <div class="col-md-6">
    <h2>Project Goal:</h2>
    <p>The goal is to develop this project is reading, writing, deleting, updating data and writing to a XML file. On the other hand
    this project will read data from the uploaded XML file. File and data validation is also added here.</p>
    <a class="btn btn-success" href="list.php">View files list</a>
    </div>
  </div><hr/>
  <div class="row">
    <div class="col-md-3">
    </div>
    <div class="col-md-6">
      <form action="success.php" enctype="multipart/form-data" method="post">
        <div class="form-group">
          <label for="uploaderName">Uploader Name</label>
          <input type="text" class="form-control" id="uploaderName" placeholder="e.g; Mumu Rahman">
        </div>
        <div class="form-group">
          <label for="uploaderEmail">Uploader Email</label>
          <input type="email" class="form-control" id="uploaderEmail" placeholder="e.g; mumu@green.edu.bd">
        </div>
        <div class="form-group">
          <label for="exampleInputFile">File input</label>
          <input type="file" name="file_upload" id="file_upload" multiple>
          <p class="help-block">Upload only .xml exntension file to execute the operation</p>
        </div>
        <div class="checkbox">
          <label>
            <input type="checkbox"> <a href="#">Terms and Conditions</a>
          </label>
        </div>
        <button type="submit" name="submit" class="btn btn-success">Start Uploading</button>
    </form>
    </div>
    <div class="col-md-3">
    </div>
  </div>
<?php require_once('inc/footer.php'); ?>
