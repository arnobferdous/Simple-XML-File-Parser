<?php require_once('inc/header.php'); ?>
<?php require_once('inc/sub-header.php'); ?>
  <div class="rows">
    <table class="table table-hover">
      <tr>
        <td>ID</td>
        <td>Files</td>
        <td>Actions</td>
      </tr>
      <tr>
        <td>01</td>
        <td>users-name-address.xml</td>
        <td><a class="btn btn-success btn-xs" href="#"> Edit </a> <a class="btn btn-primary btn-xs" href="#"> Download </a> <a class="btn btn-danger btn-xs" href="#"> Delete</a></td>
      </tr>
    </table>
    <a class="btn btn-primary" style="float: right; font-weight: bold;" href="/parser">Go back</a>
  </div>
<?php require_once('inc/footer.php'); ?>
